Free content from www.my-art-gallery.co.uk



'Buoy'

I created this model in 3D Studio MAx back in 2005 for a picture I was making called 'The Distant Sound of Thunder' which
can been seen in the gallery. I based the model on photographs and tried to make it as accurate as posssible, the textures
were made in Photoshop.

You can use the model for your personal or commercial art but must not redistribute it or offer it for sale or free 
download from a website or on electronic storage material.

I do not require credit for my work but a mention would be appreciated. Let me know if you create a picture using this model,
it would be nice to see how you use it.

I have included both 3ds and pz3 files for your convenience.

Copyright of the model and textures remains with Tony Hayes all rights reserved 2006

Enjoy

Tony Hayes
